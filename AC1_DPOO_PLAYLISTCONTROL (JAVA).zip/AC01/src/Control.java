import java.util.*;

public class Control {
    private List<Music> playlist;
    private final Scanner scanner;
    private final String ERROR = "ERROR: using character, try again.\n";

    public Control() {
        this.scanner = new Scanner(System.in);
        this.playlist = new ArrayList<>();
    }

    private String askForString (String message) {
        System.out.print(message);
        return scanner.nextLine();
    }

    private int askForInt (String message, String messageError) {
        while (true) {
            try {
                System.out.print(message);
                return scanner.nextInt();
            } catch (InputMismatchException e) {
                System.out.print(messageError);
            } finally {
                scanner.nextLine();
            }
        }
    }

    private void showMenu() {
        System.out.println(
                "\nWelcome to your awesome playlist!\n\n" +
                "What do you want to do?\n\n" +
                "1. Add a new song to playlist\n" +
                "2. Delete song from playlist\n" +
                "3. List songs by artist\n" +
                "4. List top 5 songs with a specific hashtag\n" +
                "5. Exit\n");
    }

    public void menuSelect () {
        showMenu();
        int option = askForInt("Please choose an option: ", ERROR);

        while (option != 5) {
            switch (option) {
                case 1 -> addSong();
                case 2 -> deleteSong();
                case 3 -> showSong();
                case 4 -> showHashtag();
                default -> {
                    System.out.println("\n\nERROR: invalid option, try again.\n\n");
                }
            }

            showMenu();
            option = askForInt("Please choose an option: ", ERROR);
        }

        if (option == 5) {
            System.out.println("\nMay the music be with you.");
        }
    }

    public void addSong () {
        String name = askForString("Song name?");
        String artist = askForString("Artist? ");
        String genre = askForString("Genre? ");
        int year = askForInt("Year? ", ERROR);
        int rating = askForInt("How popular is this? ", ERROR);
        while (rating < 1 || rating > 10) {
            System.out.println("\tInvalido formato for rating.");
            rating = askForInt("\tHow popular is this? ", ERROR);
        }
        String hashtag = askForString("Add some hashtags to the song: ");

        Music music = new Music(name, artist, genre, year, rating, hashtag);

        playlist.add(music);
    }

    public void deleteSong () {

        String name = askForString("Song name? ");
        boolean flag;
        flag = false;

        for (Music music : playlist) {
            if (music.getSong().equals(name)) {
                playlist.remove(music);
                flag = true;
            }

            if (!flag) {
                System.out.println("\n\nERROR: invalid song, try again.\n\n");
            }
        }
    }

    public void showSong () {
        boolean flag = false;

        String artist = askForString("Artist name? ");

        for (Music music : playlist) {
            if (music.getArtist().equals(artist)) {
                System.out.println("Songs by '" + music.getArtist() + "':\n" + music.getSong() + " (" + music.getYear() + ") - " + music.getGenre());
                flag = true;
            }
        }

        if (!flag) {
            System.out.println("\nThere is no such artist registered in the playlist.");
        }
    }


      public void showHashtag () {

          String hashtag = askForString("Search by hashtag: ");
          List<Music> listaHashtag = new ArrayList<>();

          System.out.println("Top 5 Songs with the hashtag '" + hashtag + "':\n");
          boolean flag = false;
          for (Music music : playlist) {
              if (music.getHashtag().equals(hashtag)) {

                  flag = true;
                  listaHashtag.add(music);

              }


          }

          int i = 0;
          if (!flag) {
              System.out.println("\nThere is no such hashtag registered in the playlist.\n");
          }
          Collections.sort(listaHashtag);

          for (Music music : listaHashtag) {
              if (i < 5) {
                  System.out.println(music.getSong() + " " + music.getRating() + " " + music.getHashtag());
                  i++;
              }
          }
      }
}
