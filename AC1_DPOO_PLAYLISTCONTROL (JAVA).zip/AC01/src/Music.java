public class Music implements Comparable<Music> {


    private String song;
    private String artist;
    private String genre;
    private int year;
    private int rating;
    private String hashtag;

    public Music(String song, String artist, String genre, int year, int rating, String hashtag) {
        this.song = song;
        this.artist = artist;
        this.genre = genre;
        this.year = year;
        this.rating = rating;
        this.hashtag = hashtag;
    }

    public String getSong() {
        return song;
    }

    public void setSong(String song) {
        this.song = song;
    }

    public String getArtist() {
        return artist;
    }

    public void setArtist(String artist) {
        this.artist = artist;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public String getHashtag() {
        return hashtag;
    }

    public void setHashtag(String hashtag) {
        this.hashtag = hashtag;
    }


    @Override
    public int compareTo(Music o) {
        if (getRating() > o.getRating()) {
            return -1;
        } else if (getRating() < o.getRating()) {
            return 1;
        } else {
            return 0;
        }
    }
}
